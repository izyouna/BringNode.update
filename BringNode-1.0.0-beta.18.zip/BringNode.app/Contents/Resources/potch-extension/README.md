# BringNode Connected

ส่วนขยาย Chromium สำหรับส่งรายการเพลง/วิดีโอ ควบคุม Like/Shuffle ของเครื่องเล่นที่รองรับ และส่งสายเรียกเข้า Messenger / Instagram ไปยัง BringNode ผ่าน native messaging host `com.potch.callbridge` ที่รวมอยู่ในแอป ไม่ใช้ backend และไม่เชื่อมกับส่วนขยายของแอปอื่น

## ติดตั้งสำหรับทดสอบ

1. เปิด BringNode รุ่นที่ build ล่าสุดก่อน เพื่อให้แอปลงทะเบียน native host
2. ใน Chrome เปิด `chrome://extensions` แล้วเปิด Developer mode
3. เลือก **Load unpacked** และเลือกโฟลเดอร์นี้ที่มี `manifest.json` (ไม่เลือกไฟล์ ZIP)
4. Reload แท็บ YouTube, Messenger และ Instagram ที่เปิดก่อนติดตั้ง แล้วเปิดเพลงและเลือก Queue ใน BringNode
5. เปิด Incoming Web Calls ใน Settings → Browser หากปิดไว้ สายเรียกเข้าจะแสดงเมื่อแท็บเว็บมี dialog พร้อมปุ่มรับและปฏิเสธสายที่ตรวจพบ

BringNode Settings > Browser > Add Extension opens the selected browser extensions page and reveals the bundled potch-extension folder in Finder. Installation still requires Developer mode and Load unpacked in the browser. The adjacent options menu lets you choose another installed browser or read the setup guide. For development, load this source folder; reload the extension and relevant tabs after changes.

## ขอบเขต

- YouTube: อ่าน playlist ที่ render แล้ว หรือรายการแนะนำเมื่อไม่มี playlist; รายการแนะนำไม่ใช่คิว autoplay ที่รับรองลำดับครบถ้วน รองรับ renderer รุ่นเดิมและ `yt-lockup-view-model` ส่งสูงสุด30รายการเริ่มจากเพลงปัจจุบันเมื่อพบ
- YouTube Music: อ่านรายการที่ render ใน player queue; คิวที่เว็บยังไม่โหลดหรือยังไม่ render อาจไม่ครบ
- เลือกแถวเพลงส่งคำสั่งกลับแท็บต้นทาง ตรวจชื่อ/รหัสเพลงเมื่อมีเพื่อไม่กดแถวเก่าหลังหน้าเว็บเปลี่ยน
- Messenger/Facebook และ Instagram: ตรวจ dialog ที่มองเห็นพร้อมปุ่ม Answer/Accept และ Decline/Reject รวมคำไทย รับ/ปฏิเสธสายได้เมื่อพบปุ่มจริง การตอบกลับยืนยันการคลิก ไม่ยืนยันว่าเชื่อมต่อสายสำเร็จ
- ไม่ใช่ระบบโทรศัพท์ ไม่รองรับสายจากทุกแอป ไม่มีการสร้างสายเอง ไม่มีการดักเสียง/ภาพ และยังไม่มีปุ่มวางสายที่เชื่อมต่อแล้วใน BringNode
- ไม่ขอ microphone/camera permissions เอง เว็บไซต์และ browser จัดการสิทธิ์เหล่านั้นตามปกติ
- ใช้ host permissions เฉพาะ Messenger, Facebook, Instagram และ YouTube ตาม manifest; Spotify Web, Apple Music Web และ SoundCloud เป็นสิทธิ์เสริมที่ผู้ใช้เลือกเปิดเอง ใช้ `nativeMessaging`, `downloads` และ `scripting` สำหรับตัวเชื่อม ดาวน์โหลด และแนบสคริปต์ของส่วนขยายกลับเข้าแท็บที่ได้รับสิทธิ์แล้ว
- Safari ยังไม่รองรับ ไม่ได้เผยแพร่ Chrome Web Store; การติดตั้ง unpacked ต้องทำครั้งแรกด้วยผู้ใช้

## Verification

Run from the repository root:

```sh
python3 -m unittest discover -s tests -p 'test_browser_bridge.py' -v
```

DOM fixtures cover queue row mapping, stale commands, Thai/English call controls and outgoing-call exclusion. Routing/native harnesses cover matching acknowledgements and tab cleanup. These checks do not prove compatibility with every current account layout or a live call. Real YouTube/call verification requires installing the extension and a consenting test caller; tests never initiate or answer a real call.

## Security update (2026-10-18)

Update the BringNode app and Reload this existing unpacked extension in `chrome://extensions` (or restart Chrome) together. The native host now requires a supported signed browser parent and talks to BringNode through a private socket with mutual code-signature verification. Old Distributed Notifications/JSON-file producers are retired. The worker accepts only matching HTTPS site events from its own main-frame scripts and rejects commands without session/command IDs.

Production app packaging requires Developer ID/notarization; the local Potch Dev build is only a development test. The extension's public key/JavaScript are inspectable and are not credentials. A Chrome Web Store release is still paused.

### Reload and existing tabs

After Reload in `chrome://extensions`, refresh existing YouTube/YouTube Music, Messenger and Instagram tabs once to load the new content scripts. Chrome does not replace scripts already running in a page. An old `Extension context invalidated` entry refers to the orphaned script; Reload alone cannot patch that old in-memory copy. New scripts stop polling, navigation callbacks and call DOM observation when their runtime is invalidated, without swallowing unrelated programming errors. Ordinary delivery errors remain retryable. No extra permissions or automatic website reloads were added.

## Music and video controls (2026-10-18)

Regular YouTube clips now appear in Queue as well as YouTube Music. Like/Shuffle route to the current web player with observed-state acknowledgement. When ordinary YouTube has no Shuffle button, BringNode can shuffle its rendered next-video list and advance at the current main clip's end; enabling Shuffle does not interrupt the clip. A video without next candidates cannot shuffle.

Click **BringNode Connected** in Chrome's Extensions menu to enable **Spotify Web**, **Apple Music Web**, or **SoundCloud** individually. Chrome asks for that website's optional access; no other music website is enabled automatically. Open a song/playlist afterward. The extension reattaches its own isolated script to existing granted tabs after Reload, without refreshing the page. Native Spotify/Music apps do not need this browser permission.

Only controls actually available in the player's current layout can be used. Details and live-verification limits: [Browser media actions](../../Docs/Potch/BrowserMediaActions20261018.md).
