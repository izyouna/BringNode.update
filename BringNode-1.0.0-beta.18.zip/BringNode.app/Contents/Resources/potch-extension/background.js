/**
 * BringNode Connected Extension - Background Service Worker
 * Manages native messaging connection with com.potch.callbridge
 * and routes download progress and web call events.
 */

const NATIVE_HOST = "com.potch.callbridge";
let nativePort = null;
const callTabs = new Map();
let queueTabId = null;
let queuePlaying = false;
let queueOrigin = null;
let queueSnapshot = null;
const callSnapshots = new Map();
const bridgeId = crypto.randomUUID();

function connectNative() {
  if (nativePort) return;
  try {
    nativePort = chrome.runtime.connectNative(NATIVE_HOST);
    console.log("[BringNode] Connected to Native Messaging Host:", NATIVE_HOST);

    nativePort.onMessage.addListener((msg) => {
      handleNativeResponse(msg);
    });

    for (const message of callSnapshots.values()) sendToPotch(message);
    if (queueSnapshot) sendToPotch(queueSnapshot);

    nativePort.onDisconnect.addListener(() => {
      console.log("[BringNode] Native port disconnected:", chrome.runtime.lastError?.message);
      nativePort = null;
      // Retry connection after 5 seconds
      setTimeout(connectNative, 5000);
    });
  } catch (err) {
    console.error("[BringNode] Failed to connect native:", err);
  }
}

function sendToPotch(payload) {
  if (!nativePort) {
    connectNative();
  }
  if (nativePort) {
    try {
      nativePort.postMessage({...payload, bridgeId});
    } catch (err) {
      console.error("[BringNode] Error posting to native:", err);
    }
  }
}

// Handle action responses coming back from BringNode UI
function handleNativeResponse(response) {
  if (!response || response.bridgeId !== bridgeId || !uuid(response.commandId) || completedCommands.has(response.commandId)) return;
  if (completedCommands.size >= 256) completedCommands.delete(completedCommands.values().next().value);
  completedCommands.add(response.commandId);
  const { action, callId, downloadId } = response;

  if (action === "accept" || action === "decline") {
    const tabId = callTabs.get(callId);
    if (Number.isInteger(tabId)) {
      chrome.tabs.sendMessage(tabId, { action, callId, commandId: response.commandId }, (result) => {
        const ok = !chrome.runtime.lastError && result?.ok === true;
        sendToPotch({type: "callActionResult", id: callId, commandId: response.commandId, ok});
      });
    } else {
      sendToPotch({type: "callActionResult", id: callId, commandId: response.commandId, ok: false});
    }
  } else if (action === 'refreshQueue') {
    refreshQueues();
  } else if (['setLike', 'setShuffle'].includes(action)) {
    if (!Number.isInteger(queueTabId) || typeof response.enabled !== 'boolean' || !text(response.title, 512) || response.title !== queueSnapshot?.mediaTitle) return;
    chrome.tabs.sendMessage(queueTabId, {action, title: response.title, enabled: response.enabled}, result => {
      sendToPotch({type: 'mediaActionResult', commandId: response.commandId,
        ok: !chrome.runtime.lastError && result?.ok === true});
    });
  } else if (action === "playQueueIndex" || action === "playRow") {
    if (Number.isInteger(queueTabId) && Number.isSafeInteger(response.index) && response.index >= 0 && response.index <= 100000) {
      chrome.tabs.sendMessage(queueTabId, { action, index: response.index, title: response.title, videoId: response.videoId }, () => void chrome.runtime.lastError);
    }
  } else if (["pauseDownload", "resumeDownload", "cancelDownload"].includes(action)) {
    const id = Number(downloadId);
    if (!Number.isSafeInteger(id) || id < 0 || downloadId == null) return;
    const operation = {pauseDownload: "pause", resumeDownload: "resume", cancelDownload: "cancel"}[action];
    chrome.downloads[operation](id, () => {
      const ok = !chrome.runtime.lastError;
      sendToPotch({type: "downloadActionResult", id: String(id), commandId: response.commandId, ok});
    });
  }
}

// MARK: - Download Progress Tracking
if (chrome.downloads) {
  chrome.downloads.onChanged.addListener((delta) => {
    chrome.downloads.search({ id: delta.id }, (items) => {
      if (!items || !items.length) return;
      const dl = items[0];

      let state = "in_progress";
      if (dl.state === "complete") state = "complete";
      if (dl.state === "interrupted") state = "cancelled";
      if (dl.paused) state = "paused";

      const fileName = dl.filename ? dl.filename.split("/").pop().split("\\").pop() : "File";

      sendToPotch({
        type: "downloadProgress",
        id: String(dl.id),
        fileName: fileName,
        bytesReceived: dl.bytesReceived || 0,
        totalBytes: dl.totalBytes || 0,
        speed: 0,
        state: state
      });
    });
  });
}

// Only main-frame content scripts on the matching service may send events.
const completedCommands = new Set();
const rates = new Map();
const uuid = value => typeof value === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value);
const text = (value, max, empty = false) => typeof value === 'string' && (empty || value.length > 0) && new TextEncoder().encode(value).length <= max;
const integer = (value, min = 0, max = 100000) => Number.isSafeInteger(value) && value >= min && value <= max;
const artworkHosts = new Set(['i.ytimg.com', 'i9.ytimg.com', 'lh3.googleusercontent.com', 'yt3.ggpht.com', 'yt3.googleusercontent.com']);
function artwork(value) {
  if (!text(value, 2048)) return '';
  try {
    const url = new URL(value);
    return url.protocol === 'https:' && !url.username && !url.password && !url.port && artworkHosts.has(url.hostname) ? url.href : '';
  } catch { return ''; }
}
function receiveContent(message, sender, sendResponse) {
  if (sender.id !== chrome.runtime.id || !Number.isInteger(sender.tab?.id) || sender.frameId !== 0 || !message || typeof message !== 'object') return;
  let url;
  try { url = new URL(sender.url); } catch { return; }
  if (url.protocol !== 'https:' || sender.origin !== url.origin) return;
  const host = url.hostname;
  const youtube = ['www.youtube.com', 'youtube.com', 'music.youtube.com', 'm.youtube.com'].includes(host);
  const webSource = host === 'open.spotify.com' ? 'Spotify' : host === 'music.apple.com' ? 'Apple Music' : ['soundcloud.com', 'www.soundcloud.com'].includes(host) ? 'SoundCloud' : null;
  const platform = ['www.instagram.com', 'instagram.com'].includes(host) ? 'Instagram' :
    ['www.messenger.com', 'messenger.com', 'www.facebook.com', 'facebook.com', 'web.facebook.com'].includes(host) ? 'Messenger' : null;
  if (!youtube && !webSource && !platform) return;
  const now = Date.now(), key = sender.tab.id;
  let rate = rates.get(key);
  if (!rate || now - rate.start >= 1000) { rate = {start: now, count: 0}; rates.set(key, rate); }
  if (++rate.count > 8) return;
  let payload;
  if (message.type === 'incomingCall' && platform && text(message.id, 128) && text(message.caller, 512) && typeof message.isVideo === 'boolean') {
    if ((callTabs.has(message.id) && callTabs.get(message.id) !== key) || (!callTabs.has(message.id) && callTabs.size >= 16)) return;
    payload = {type: 'incomingCall', id: message.id, caller: message.caller, platform, isVideo: message.isVideo};
    callTabs.set(message.id, key);
    callSnapshots.set(message.id, payload);
  } else if (message.type === 'callEnded' && platform && text(message.id, 128)) {
    if (callTabs.get(message.id) !== key) return;
    callTabs.delete(message.id); callSnapshots.delete(message.id);
    payload = {type: 'callEnded', id: message.id};
  } else if (message.type === 'ytMusicQueue' && (youtube || webSource)) {
    if (!Array.isArray(message.items) || message.items.length > 30 || typeof message.playing !== 'boolean' || !integer(message.cur, -1)) return;
    const items = [];
    for (const item of message.items) {
      if (!item || !integer(item.index) || !text(item.title, 512) || !text(item.artist, 512) || !text(item.duration, 32) || typeof item.isSelected !== 'boolean') return;
      items.push({index: item.index, title: item.title, artist: item.artist, duration: item.duration,
        isSelected: item.isSelected, thumb: artwork(item.thumb),
        videoId: typeof item.videoId === 'string' && /^[\w-]{11}$/.test(item.videoId) ? item.videoId : null});
    }
    if (queueTabId !== null && queueTabId !== key && (items.length === 0 || (queuePlaying && !message.playing))) return;
    const mediaTitle = text(message.mediaTitle, 512) ? message.mediaTitle : '';
    for (const field of ['canLike', 'canShuffle', 'isLiked', 'isShuffled']) if (message[field] != null && typeof message[field] !== 'boolean') return;
    payload = {type: 'ytMusicQueue', source: webSource || (host === 'music.youtube.com' ? 'YouTube Music' : 'YouTube'),
      mediaTitle, canLike: !!message.canLike, canShuffle: !!message.canShuffle,
      isLiked: !!message.isLiked, isShuffled: !!message.isShuffled, cur: message.cur, playing: message.playing, items};
    queueTabId = key; queueOrigin = url.origin; queuePlaying = message.playing; queueSnapshot = payload;
  } else { return; }
  sendToPotch(payload);
  sendResponse({ok: true});
}
chrome.runtime.onMessage.addListener((message, sender, respond) => {
  let url;
  try { url = new URL(sender.url); } catch { return; }
  if (['open.spotify.com', 'music.apple.com', 'soundcloud.com', 'www.soundcloud.com'].includes(url.hostname)) {
    chrome.permissions.contains({origins: [`${url.origin}/*`]}, granted => {
      if (granted && !chrome.runtime.lastError) receiveContent(message, sender, respond);
      else respond({ok: false});
    });
    return true;
  }
  return receiveContent(message, sender, respond);
});
chrome.permissions.onRemoved.addListener(permissions => {
  if (queueOrigin && (permissions.origins || []).includes(`${queueOrigin}/*`)) clearTab(queueTabId);
});

function clearTab(id) {
  rates.delete(id);
  for (const [callId, tabId] of callTabs) {
    if (tabId === id) {
      sendToPotch({type: "callEnded", id: callId, tabId: id});
      callTabs.delete(callId);
      callSnapshots.delete(callId);
    }
  }
  if (queueTabId === id) {
    queueTabId = null;
    queueOrigin = null;
    queuePlaying = false;
    const oldSource = queueSnapshot?.source;
    queueSnapshot = null;
    sendToPotch({type: "ytMusicQueue", source: oldSource || "YouTube", cur: -1, items: [], playing: false});
  }
}
chrome.tabs.onRemoved.addListener(clearTab);
chrome.tabs.onUpdated.addListener((id, change) => {
  if (change.status === 'loading') clearTab(id);
  if (change.status === 'complete') refreshQueues();
});

// onChanged omits ordinary received-byte updates; poll active transfers for a live meter.
setInterval(() => {
  if (!nativePort || !chrome.downloads) return;
  chrome.downloads.search({state: "in_progress"}, (items) => {
    for (const dl of (items || []).slice(0, 32)) {
      sendToPotch({type: "downloadProgress", id: String(dl.id),
        fileName: (dl.filename || "File").split(/[\\/]/).pop(),
        bytesReceived: dl.bytesReceived || 0, totalBytes: dl.totalBytes || 0,
        speed: 0, state: dl.paused ? "paused" : "in_progress"});
    }
  });
}, 1000);
setInterval(() => sendToPotch({type: "heartbeat"}), 10000);

connectNative();

// Ask matching tabs to publish a fresh DOM snapshot; never reload websites automatically.
function refreshQueues() {
  chrome.tabs.query({url: ['https://www.youtube.com/*', 'https://youtube.com/*', 'https://music.youtube.com/*',
    'https://m.youtube.com/*', 'https://open.spotify.com/*', 'https://music.apple.com/*',
    'https://soundcloud.com/*', 'https://www.soundcloud.com/*']}, tabs => {
    if (chrome.runtime.lastError) return;
    for (const tab of (tabs || []).slice(0, 32)) {
      let url;
      try { url = new URL(tab.url); } catch { continue; }
      if (url.protocol !== 'https:' || !['www.youtube.com', 'youtube.com', 'music.youtube.com', 'm.youtube.com',
        'open.spotify.com', 'music.apple.com', 'soundcloud.com', 'www.soundcloud.com'].includes(url.hostname)) continue;
      chrome.tabs.sendMessage(tab.id, {action: 'refreshQueue'}, () => {
        if (!chrome.runtime.lastError) return;
        // Reattach our own isolated script to an old tab after an extension reload.
        chrome.scripting.executeScript({target: {tabId: tab.id, frameIds: [0]},
          files: ['content-scripts/ytmusic.js']}).catch(() => {});
      });
    }
  });
}
refreshQueues();
