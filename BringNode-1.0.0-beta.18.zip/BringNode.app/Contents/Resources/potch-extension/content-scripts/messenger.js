/** Incoming calls only: a visible dialog must expose both answer and decline. */
(() => {
  let stopped = false;
  let pollTimer;
  function runtimeAvailable() {
    if (stopped) return false;
    try {
      if (chrome.runtime?.id) return true;
    } catch (error) {
      if (!/Extension context invalidated/i.test(error.message)) throw error;
    }
    stop();
    return false;
  }
  function send(message) {
    if (!runtimeAvailable()) return;
    try {
      chrome.runtime.sendMessage(message, () => {
        if (!runtimeAvailable()) return;
        // Consume ordinary delivery errors; a future poll can retry a sleeping worker.
        try { void chrome.runtime.lastError; }
        catch (error) {
          if (!/Extension context invalidated/i.test(error.message)) throw error;
          stop();
        }
      });
    } catch (error) {
      if (!/Extension context invalidated/i.test(error.message)) throw error;
      stop();
    }
  }
  const platform = location.hostname.endsWith('instagram.com') ? 'Instagram' : 'Messenger';
  let active = null;
  let scheduled = false;
  const completedCommands = new Set();
  const visible = el => !!el && !el.hidden && el.getAttribute('aria-hidden') !== 'true' && el.getClientRects().length > 0;
  function controls(dialog) {
    const buttons = [...dialog.querySelectorAll('button, [role="button"]')].filter(el =>
      visible(el) && !el.disabled && el.getAttribute('aria-disabled') !== 'true');
    const label = el => (el.getAttribute('aria-label') || el.textContent || '').trim();
    return {
      accept: buttons.find(el => /^(answer|accept)(\b|$)|^(รับสาย|ยอมรับ)/i.test(label(el))),
      decline: buttons.find(el => /^(decline|reject)(\b|$)|^(ปฏิเสธ|ตัดสาย|ไม่รับสาย)/i.test(label(el)))
    };
  }
  function incoming() {
    const dialogs = document.querySelectorAll('[role="dialog"], [data-testid="incoming_call_dialog"], [aria-label*="Incoming call" i], [aria-label*="สายเรียกเข้า"]');
    return [...dialogs].find(el => visible(el) && controls(el).accept && controls(el).decline);
  }
  function stop() {
    if (stopped) return;
    stopped = true;
    clearInterval(pollTimer);
    clearTimeout(checkTimer);
    observer.disconnect();
    active = null;
    completedCommands.clear();
  }
  function check() {
    if (!runtimeAvailable()) return;
    const dialog = incoming();
    if (active && active.dialog !== dialog) {
      send({type: 'callEnded', id: active.id});
      if (stopped) return;
      active = null;
      completedCommands.clear();
    }
    if (!dialog) return;
    if (!active) active = {id: crypto.randomUUID(), dialog};
    const name = dialog.querySelector('h1, h2, h3, [role="heading"], strong, span[dir="auto"]');
    send({type: 'incomingCall', id: active.id, platform,
      caller: (name?.textContent || '').trim() || 'Incoming Call',
      isVideo: !!dialog.querySelector('[aria-label*="video" i], [aria-label*="วิดีโอ"], [aria-label*="กล้อง"]'),
      avatar: dialog.querySelector('img[src*="fbcdn"], img[src*="cdninstagram"]')?.src || null
    });
  }
  chrome.runtime.onMessage.addListener((message, _sender, respond) => {
    if (!runtimeAvailable()) return;
    if (!['accept', 'decline'].includes(message.action)) return;
    if (!active || active.id !== message.callId || incoming() !== active.dialog ||
        !message.commandId || completedCommands.has(message.commandId)) { respond({ok: false}); return; }
    const button = controls(active.dialog)[message.action];
    if (!button) { respond({ok: false}); return; }
    completedCommands.add(message.commandId);
    button.click();
    respond({ok: true}); // Acknowledges the click; the website still owns call connection.
  });
  let checkTimer;
  const observer = new MutationObserver(() => {
    if (!runtimeAvailable() || scheduled) return;
    scheduled = true;
    checkTimer = setTimeout(() => { scheduled = false; check(); }, 150);
  });
  observer.observe(document.documentElement, {childList: true, subtree: true, attributes: true,
    attributeFilter: ['aria-label', 'aria-hidden', 'aria-disabled', 'disabled', 'hidden', 'style', 'class']});
  // Also reannounce after service-worker/native-host restarts without changing call identity.
  pollTimer = setInterval(check, 3000);
  check();
})();
