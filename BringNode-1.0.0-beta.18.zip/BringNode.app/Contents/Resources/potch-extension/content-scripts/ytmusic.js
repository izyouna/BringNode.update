/** Read rendered YouTube queues; commands use the same row mapping as snapshots. */
(() => {
  if (!['www.youtube.com', 'youtube.com', 'music.youtube.com', 'm.youtube.com',
    'open.spotify.com', 'music.apple.com', 'soundcloud.com', 'www.soundcloud.com'].includes(location.hostname)) return;
  globalThis.__potchMediaStop?.();
  let stopped = false;
  let pollTimer;
  let localShuffle = false;
  let sessionVideo = null, lastShuffledVideo = null;
  const shuffleRanks = new Map();
  function runtimeAvailable() {
    if (stopped) return false;
    try {
      if (chrome.runtime?.id) return true;
    } catch (error) {
      if (!/Extension context invalidated/i.test(error.message)) throw error;
    }
    stop();
    return false;
  }
  function send(message) {
    if (!runtimeAvailable()) return;
    try {
      chrome.runtime.sendMessage(message, () => {
        if (!runtimeAvailable()) return;
        // Consume ordinary delivery errors; a future poll can retry a sleeping worker.
        try { void chrome.runtime.lastError; }
        catch (error) {
          if (!/Extension context invalidated/i.test(error.message)) throw error;
          stop();
        }
      });
    } catch (error) {
      if (!/Extension context invalidated/i.test(error.message)) throw error;
      stop();
    }
  }
  const host = location.hostname;
  const isMusic = host === 'music.youtube.com';
  const isYouTube = host.endsWith('youtube.com');
  const source = isMusic ? 'YouTube Music' : isYouTube ? 'YouTube' :
    host === 'open.spotify.com' ? 'Spotify' : host === 'music.apple.com' ? 'Apple Music' : 'SoundCloud';
  const visible = el => !!el && !el.disabled && el.getAttribute('aria-disabled') !== 'true' &&
    !el.hidden && el.getClientRects().length > 0;
  function control(action) {
    const selectors = source === 'Spotify' ? {
      like: '[data-testid="now-playing-widget"] button[data-testid="add-button"], [data-testid="now-playing-widget"] button[data-testid="add-to-liked-songs-button"]',
      shuffle: 'button[data-testid="control-button-shuffle"]'
    } : source === 'Apple Music' ? {
      like: '.web-chrome-playback-controls button[data-testid="favorite-button"], .web-chrome-playback-controls button[aria-label*="Favorite" i]',
      shuffle: 'button[data-testid="shuffle-button"], button[aria-label*="Shuffle" i]'
    } : source === 'SoundCloud' ? {
      like: '.playControls .playbackSoundBadge__like', shuffle: '.playControls .shuffleControl'
    } : isMusic ? {
      like: 'ytmusic-player-bar ytmusic-like-button-renderer #like-button',
      shuffle: 'ytmusic-player-bar .shuffle, ytmusic-player-bar #shuffle'
    } : {
      like: 'ytd-watch-metadata like-button-view-model button, #top-level-buttons-computed like-button-view-model button, ytd-watch-metadata #like-button button',
      shuffle: 'ytd-playlist-panel-renderer #shuffle-button button, ytd-playlist-panel-renderer button[aria-label*="shuffle" i], ytd-playlist-panel-renderer button[aria-label*="สุ่ม"]'
    };
    return [...document.querySelectorAll(selectors[action])].find(visible) || null;
  }
  function pressed(button, action) {
    if (!button) return false;
    const value = button.getAttribute('aria-pressed') ?? button.getAttribute('aria-checked');
    if (value != null) return value === 'true';
    return button.classList.contains('m-active') || button.classList.contains('m-shuffling') || button.hasAttribute('toggled') || button.getAttribute('aria-label')?.toLowerCase().startsWith('turn off shuffle') || button.classList.contains('sc-button-selected') ||
      (button.getAttribute('like-status') || button.closest?.('ytmusic-like-button-renderer')?.getAttribute('like-status')) === 'LIKE' ||
      (action === 'like' && /^(unlike|unfavorite|undo favorite|remove favorite|remove from|เลิกชอบ|นำออก|ยกเลิกรายการโปรด)/i.test(button.getAttribute('aria-label') || ''));
  }
  function currentTitle() {
    return text(document, source === 'Spotify' ? '[data-testid="context-item-info-title"]' :
      source === 'Apple Music' ? '.lcd-meta__primary, .web-chrome-playback-lcd__song-name' :
      source === 'SoundCloud' ? '.playbackSoundBadge__titleLink' : isMusic ?
      'ytmusic-player-bar .title' : 'ytd-watch-metadata h1, #title h1');
  }
  const musicRows = 'ytmusic-player-queue-item, ytmusic-responsive-list-item-renderer';
  const playlistRows = 'ytd-playlist-panel-video-renderer';
  const suggestedRows = 'ytd-compact-video-renderer, yt-lockup-view-model';
  const text = (el, selector) => {
    const node = el.querySelector(selector);
    return [node?.textContent, node?.innerText, node?.getAttribute?.('title')].find(s => s?.trim())?.trim().replace(/\s+/g, ' ').slice(0, 128) || '';
  };
  function rows() {
    if (!isYouTube) {
      const selector = source === 'Spotify' ? '[data-testid="queue"] [data-testid="tracklist-row"], [aria-label="Next in queue"] [data-testid="tracklist-row"]' :
        source === 'Apple Music' ? '.up-next__queue .songs-list-row' : '.queue__items .queueItem';
      return [...document.querySelectorAll(selector)];
    }
    if (isMusic) return [...document.querySelectorAll(`ytmusic-player-queue ${musicRows.split(', ').join(', ytmusic-player-queue ')}`)];
    const playlist = [...document.querySelectorAll(playlistRows)];
    return playlist.length ? playlist : [...document.querySelectorAll(`#related ${suggestedRows.split(', ').join(', #related ')}, #secondary ${suggestedRows.split(', ').join(', #secondary ')}`)];
  }
  function localCandidates() {
    if (source !== 'YouTube') return [];
    const current = new URL(location.href).searchParams.get('v');
    return rows().flatMap((row, index) => {
      const link = row.querySelector('a[href*="watch?"]');
      const id = link ? new URL(link.href, location.href).searchParams.get('v') : null;
      return id && /^[\w-]{11}$/.test(id) && id !== current ? [{row, index, id, link}] : [];
    }).slice(0, 30);
  }
  function advanceShuffledVideo(event) {
    if (!runtimeAvailable() || !localShuffle || source !== 'YouTube' || control('shuffle')) return;
    const video = document.querySelector('video.html5-main-video') || document.querySelector('video, audio');
    if (event.target !== video || !video?.ended || document.querySelector('#movie_player.ad-showing, #movie_player.ad-interrupting')) return;
    const current = new URL(location.href).searchParams.get('v');
    if (!current || lastShuffledVideo === current) return;
    const nextID = snapshot().items.find(item => !item.isSelected && item.videoId)?.videoId;
    const next = localCandidates().find(item => item.id === nextID);
    if (!next) return;
    lastShuffledVideo = current;
    next.link.click();
  }
  function rank(id) {
    if (!shuffleRanks.has(id)) shuffleRanks.set(id, Math.random());
    return shuffleRanks.get(id);
  }
  function snapshot() {
    const currentID = new URL(location.href).searchParams.get('v');
    if (sessionVideo !== currentID) { sessionVideo = currentID; lastShuffledVideo = null; shuffleRanks.clear(); }
    if (control('shuffle')) localShuffle = false;
    const items = rows().flatMap((el, index) => {
      const title = text(el, !isYouTube ? '[data-testid="internal-track-link"], .songs-list-row__song-name, .queueItem__title' : isMusic ? '.song-title, .title, .flex-columns yt-formatted-string' : '#video-title, .yt-lockup-metadata-view-model__title');
      if (!title) return [];
      const link = el.querySelector('a[href*="watch?"]');
      const videoId = link ? new URL(link.href, location.href).searchParams.get('v') : null;
      return [{index, title,
        artist: text(el, isMusic ? '.byline, .secondary-flex-columns' : '#byline, .ytd-channel-name, .yt-content-metadata-view-model__metadata-text') || 'Unknown',
        duration: text(el, '.duration, #length, ytd-thumbnail-overlay-time-status-renderer, .yt-badge-shape__text') || '--:--',
        thumb: el.querySelector('img')?.src || '', videoId,
        isSelected: el.hasAttribute('selected') || el.getAttribute('aria-current') === 'true' || !!(videoId && videoId === currentID)}];
    });
    const mediaTitle = currentTitle();
    if (isYouTube && currentID) {
      const current = items.find(item => item.videoId === currentID) || items.find(item => item.title === mediaTitle);
      if (current || mediaTitle) for (const item of items) item.isSelected = item === current;
    }
    // Ordinary watch pages may have only recommendations or a collapsed/empty queue.
    // Include the real current clip, never a simulated next track.
    if (mediaTitle && !items.some(item => item.isSelected)) items.unshift({index: 100000, title: mediaTitle,
      artist: text(document, isYouTube ? 'ytd-watch-metadata #channel-name, ytmusic-player-bar .byline' :
        '[data-testid="context-item-info-artist"], .lcd-meta__secondary, .playbackSoundBadge__lightLink') || 'Unknown',
      duration: '--:--', thumb: '', videoId: isYouTube ? currentID : null, isSelected: true});
    const selected = items.findIndex(item => item.isSelected);
    const like = control('like'), shuffle = control('shuffle');
    const video = document.querySelector('video.html5-main-video') || document.querySelector('video, audio');
    const pauseControl = !isYouTube && [...document.querySelectorAll(source === 'Spotify' ?
      '[data-testid="control-button-playpause"][aria-label="Pause"]' : source === 'Apple Music' ?
      '[aria-label="Pause"], [aria-label="หยุดพัก"]' : '.playControls .playControl.playing')].some(visible);
    let displayed = items.slice(Math.max(0, selected), Math.max(0, selected) + 30);
    if (localShuffle) displayed = items.filter(item => item.isSelected).slice(0, 1).concat(
      items.filter(item => !item.isSelected && item.videoId).sort((a, b) => rank(a.videoId) - rank(b.videoId))).slice(0, 30);
    return {type: 'ytMusicQueue', source, mediaTitle, canLike: !!like, canShuffle: !!shuffle || localCandidates().length > 0, isLiked: pressed(like, 'like'), isShuffled: shuffle ? pressed(shuffle, 'shuffle') : localShuffle,
      cur: selected >= 0 ? items[selected].index : -1, playing: !!pauseControl || (!!video && !video.paused && !video.ended),
      items: displayed};
  }
  function stop() {
    if (stopped) return;
    stopped = true;
    clearInterval(pollTimer);
    document.removeEventListener('yt-navigate-finish', readQueue);
    document.removeEventListener('ended', advanceShuffledVideo, true);
    try { chrome.runtime.onMessage.removeListener(handleMessage); } catch (error) {
      if (!/Extension context invalidated/i.test(error.message)) throw error;
    }
  }
  function readQueue() {
    if (runtimeAvailable()) send(snapshot());
  }
  function handleMessage(message, _sender, respond) {
    if (!runtimeAvailable()) return;
    if (message.action === 'refreshQueue') { readQueue(); respond({ok: true}); return; }
    if (['setLike', 'setShuffle'].includes(message.action)) {
      const action = message.action === 'setLike' ? 'like' : 'shuffle';
      const button = control(action);
      if (action === 'shuffle' && !button && source === 'YouTube' && localCandidates().length &&
          message.title === currentTitle() && typeof message.enabled === 'boolean') {
        localShuffle = message.enabled;
        shuffleRanks.clear();
        readQueue(); respond({ok: true}); return;
      }
      if (!button || typeof message.enabled !== 'boolean' || !message.title || message.title !== currentTitle()) {
        respond({ok: false}); return;
      }
      if (pressed(button, action) !== message.enabled) button.click();
      // Read state again; acknowledge delivery separately from the observed toggle state.
      readQueue(); respond({ok: true}); return;
    }
    if (!['playQueueIndex', 'playRow'].includes(message.action)) return;
    if (!Number.isInteger(message.index) || message.index < 0) { respond({ok: false}); return; }
    const item = snapshot().items.find(item => item.index === message.index);
    if (!item || (message.videoId && item.videoId !== message.videoId) || (message.title && item.title !== message.title)) {
      respond({ok: false}); return;
    }
    if (item.isSelected) {
      const media = document.querySelector('video.html5-main-video') || document.querySelector('video, audio');
      if (!media) { respond({ok: false}); return; }
      // Resume the current row instead of clicking a toggle or acknowledging a no-op.
      try {
        Promise.resolve(media.play()).then(() => {
          if (!runtimeAvailable()) { respond({ok: false}); return; }
          readQueue(); respond({ok: !media.paused && !media.ended});
        }, () => respond({ok: false}));
      } catch { respond({ok: false}); return; }
      return true;
    }
    const row = rows()[message.index];
    const target = row?.querySelector(isMusic ? '.song-title, a[href*="watch?"]' : 'a#wc-endpoint, a[href*="watch?"]') || row;
    if (!target) { respond({ok: false}); return; }
    target.click();
    respond({ok: true});
  }
  chrome.runtime.onMessage.addListener(handleMessage);
  globalThis.__potchMediaStop = stop;
  pollTimer = setInterval(readQueue, 3000);
  document.addEventListener('yt-navigate-finish', readQueue);
  document.addEventListener('ended', advanceShuffledVideo, true);
  readQueue();
})();
