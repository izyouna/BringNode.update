const services = {
  spotify: ['https://open.spotify.com/*'],
  apple: ['https://music.apple.com/*'],
  soundcloud: ['https://soundcloud.com/*', 'https://www.soundcloud.com/*']
};
const status = document.querySelector('#status');
for (const button of document.querySelectorAll('button[data-service]')) {
  const origins = services[button.dataset.service];
  chrome.permissions.contains({origins}).then(granted => { if (granted) button.textContent = 'Reconnect'; });
  button.addEventListener('click', async () => {
    // Only a direct user click requests optional website access.
    try {
      const granted = await chrome.permissions.request({origins});
      if (!granted) { status.textContent = 'Website access was not enabled.'; return; }
      button.disabled = true;
      const id = `potch-${button.dataset.service}`;
      const existing = await chrome.scripting.getRegisteredContentScripts({ids: [id]});
      if (!existing.length) await chrome.scripting.registerContentScripts([{id, matches: origins,
        js: ['content-scripts/ytmusic.js'], runAt: 'document_idle', allFrames: false}]);
      const tabs = await chrome.tabs.query({url: origins});
      for (const tab of tabs.slice(0, 32)) await chrome.scripting.executeScript({target: {tabId: tab.id, frameIds: [0]}, files: ['content-scripts/ytmusic.js']}).catch(() => {});
      button.textContent = 'Reconnect';
      status.textContent = 'Connected. Open a song or video to sync with BringNode.';
    } catch { status.textContent = 'Could not connect. Check extension website access and try again.'; }
    finally { button.disabled = false; }
  });
}
