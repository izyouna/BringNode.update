// Per-site switches; the worker reads the same key and ignores switched-off sites.
const status = document.querySelector('#status');
const switches = [...document.querySelectorAll('input[data-service]')];
chrome.storage.local.get('enabledServices').then(({enabledServices = {}}) => {
  for (const input of switches) input.checked = enabledServices[input.dataset.service] !== false;
});
for (const input of switches) input.addEventListener('change', async () => {
  const {enabledServices = {}} = await chrome.storage.local.get('enabledServices');
  enabledServices[input.dataset.service] = input.checked;
  await chrome.storage.local.set({enabledServices});
  status.textContent = input.checked ? 'Connected. Open a song or video to sync with BringNode.' : 'This site no longer connects to BringNode.';
});
