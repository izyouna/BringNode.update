/** Web meetings and ongoing calls (Google Meet, Zoom web, Teams web, Instagram, Messenger): reports an in-call state while a visible Leave control exists. */
(() => {
  let stopped = false;
  let pollTimer;
  let checkTimer;
  let scheduled = false;
  function runtimeAvailable() {
    if (stopped) return false;
    try {
      if (chrome.runtime?.id) return true;
    } catch (error) {
      if (!/Extension context invalidated/i.test(error.message)) throw error;
    }
    stop();
    return false;
  }
  function send(message) {
    if (!runtimeAvailable()) return;
    try {
      chrome.runtime.sendMessage(message, () => {
        if (!runtimeAvailable()) return;
        try { void chrome.runtime.lastError; }
        catch (error) {
          if (!/Extension context invalidated/i.test(error.message)) throw error;
          stop();
        }
      });
    } catch (error) {
      if (!/Extension context invalidated/i.test(error.message)) throw error;
      stop();
    }
  }
  const host = location.hostname;
  const platform = host === 'meet.google.com' ? 'Google Meet' : host.endsWith('zoom.us') ? 'Zoom' :
    host.endsWith('instagram.com') ? 'Instagram' : /(^|\.)(messenger|facebook)\.com$/.test(host) ? 'Messenger' : 'Teams';
  const social = platform === 'Instagram' || platform === 'Messenger';
  const visible = el => !!el && !el.hidden && el.getAttribute('aria-hidden') !== 'true' && el.getClientRects().length > 0;
  const label = el => (el.getAttribute('aria-label') || el.getAttribute('title') || el.textContent || '').trim();
  function buttons() {
    return [...document.querySelectorAll('button, [role="button"]')].filter(el =>
      visible(el) && !el.disabled && el.getAttribute('aria-disabled') !== 'true');
  }
  function controls() {
    const all = buttons();
    // Social sites also show unrelated "Leave …" buttons, so they need an explicit end-call label.
    const leavePattern = social ? /^(end call|hang up|leave call|วางสาย|จบการโทร|ออกจากการโทร)(\s|\(|$)/i
      : /^(leave( call| meeting)?|end call|hang up|ออกจากการโทร|ออกจากการประชุม|วางสาย)(\s|\(|$)/i;
    const leave = all.find(el => el.id === 'hangup-button' || leavePattern.test(label(el)));
    // Meet/Teams name the action: "Turn off microphone" means the mic is live.
    const micOff = all.find(el => /^(turn off microphone|mute( microphone| mic)?|ปิดไมโครโฟน)(\s|\(|$)/i.test(label(el)));
    const micOn = all.find(el => /^(turn on microphone|unmute( microphone| mic)?|เปิดไมโครโฟน)(\s|\(|$)/i.test(label(el)));
    // Camera and screen share are named the same way: the label is the action the button performs.
    const camOff = all.find(el => /^(turn off camera|turn camera off|stop video|ปิดกล้อง)(\s|\(|$)/i.test(label(el)));
    const camOn = all.find(el => /^(turn on camera|turn camera on|start video|เปิดกล้อง)(\s|\(|$)/i.test(label(el)));
    const shareStop = all.find(el => /^(stop (sharing|presenting|screen share)|หยุดแชร์)(\s|\(|$)/i.test(label(el)));
    const shareStart = all.find(el => /^(share (your )?screen|present( now)?|screen share|แชร์หน้าจอ)(\s|\(|$)/i.test(label(el)));
    return {leave, mic: micOff || micOn, muted: micOn && !micOff ? true : micOff ? false : null,
      camera: camOff || camOn, cameraOff: camOn && !camOff ? true : camOff ? false : null,
      share: shareStop || shareStart, sharing: shareStop ? true : shareStart ? false : null};
  }
  function title() {
    if (social) return caller().name; // Inbox titles are not call names.
    const raw = document.title.replace(/\s*[-|–]\s*(Google Meet|Zoom|Microsoft Teams)\s*$/i, '').replace(/^(Meet|Zoom)\s*[-|–]\s*/i, '').trim();
    return raw.length > 0 && raw.length <= 200 && !/^(google meet|zoom|microsoft teams)$/i.test(raw) ? raw : '';
  }
  // Caller profile on Instagram/Messenger call screens: the largest visible CDN avatar and its name.
  function caller() {
    const img = [...document.querySelectorAll('img[src*="fbcdn.net"], img[src*="cdninstagram.com"]')]
      .filter(el => visible(el) && el.getBoundingClientRect().width >= 40)
      .sort((a, b) => b.getBoundingClientRect().width - a.getBoundingClientRect().width)[0];
    const alt = (img?.alt || '').replace(/(['’]s)?\s*profile (picture|photo)$/i, '').replace(/^(รูปโปรไฟล์ของ|รูปโปรไฟล์)\s*/, '').trim();
    const heading = [...document.querySelectorAll('h1, h2, [role="heading"]')].find(visible);
    const name = (alt && !/^(profile|user)/i.test(alt) ? alt : (heading?.textContent || '').trim()).slice(0, 200);
    return {name, avatar: img?.src && img.src.length <= 2048 ? img.src : null};
  }
  let active = null;
  let lastSent = '';
  function stop() {
    if (stopped) return;
    stopped = true;
    clearInterval(pollTimer);
    clearTimeout(checkTimer);
    observer.disconnect();
    globalThis.removeEventListener?.('focus', onFocusChange);
    globalThis.removeEventListener?.('blur', onFocusChange);
    active = null;
  }
  function onFocusChange() { check(); }
  function check(heartbeat = false) {
    if (!runtimeAvailable()) return;
    const state = controls();
    if (!state.leave) {
      if (active) { send({type: 'meetingEnded', id: active.id}); active = null; lastSent = ''; }
      return;
    }
    if (!active) active = {id: crypto.randomUUID(), startedAt: Date.now()};
    const message = {type: 'meetingState', id: active.id, platform, title: title(), startedAt: active.startedAt,
      muted: state.muted, canMute: !!state.mic, cameraOff: state.cameraOff, canCamera: !!state.camera,
      sharing: state.sharing, canShare: !!state.share, avatar: social ? caller().avatar : null,
      focused: document.hasFocus?.() === true}; // BringNode hides the call while its own tab is in front.
    // DOM churn re-runs check constantly; only changes and the 3 s heartbeat reach BringNode.
    const key = JSON.stringify(message);
    if (!heartbeat && key === lastSent) return;
    lastSent = key;
    send(message);
  }
  chrome.runtime.onMessage.addListener((message, _sender, respond) => {
    if (!runtimeAvailable()) return;
    if (!['meetingMute', 'meetingLeave', 'meetingCamera', 'meetingShare'].includes(message.action)) return;
    if (!active || active.id !== message.meetingId) { respond({ok: false}); return; }
    const state = controls();
    const button = {meetingLeave: state.leave, meetingMute: state.mic, meetingCamera: state.camera, meetingShare: state.share}[message.action];
    if (!button) { respond({ok: false}); return; }
    button.click();
    respond({ok: true});
    setTimeout(check, 300);
  });
  const observer = new MutationObserver(() => {
    if (!runtimeAvailable() || scheduled) return;
    scheduled = true;
    checkTimer = setTimeout(() => { scheduled = false; check(); }, 250);
  });
  observer.observe(document.documentElement, {childList: true, subtree: true, attributes: true,
    attributeFilter: ['aria-label', 'aria-hidden', 'aria-disabled', 'disabled', 'hidden', 'data-is-muted']});
  // Re-announce after service-worker/native-host restarts without changing meeting identity.
  globalThis.addEventListener?.('focus', onFocusChange);
  globalThis.addEventListener?.('blur', onFocusChange);
  pollTimer = setInterval(() => check(true), 3000);
  check();
})();
